# حارس الكرسي الرقمي — قواعد ProGuard

# الحفاظ على أسماء الكلاسات الأمنية
-keep class com.alkursi.guard.** { *; }

# الحفاظ على خدمة الحراسة
-keep class com.alkursi.guard.GuardService { *; }
-keep class com.alkursi.guard.BootReceiver { *; }

# منع تقليص مكتبة التشفير
-keep class javax.crypto.** { *; }
-keep class java.security.** { *; }

# الحفاظ على Kotlin coroutines
-keep class kotlinx.coroutines.** { *; }

# منع إزالة السجلات الأمنية
-keepclassmembers class com.alkursi.guard.SecurityLogManager { *; }
