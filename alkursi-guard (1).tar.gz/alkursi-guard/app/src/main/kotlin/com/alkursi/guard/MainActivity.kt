package com.alkursi.guard

import android.app.AppOpsManager
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val encryptionManager = EncryptionManager()
    private val logManager = SecurityLogManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        logManager.init(this)

        setContentView(buildMainLayout())
        requestOverlayPermission()
        startGuardService()
    }

    private fun buildMainLayout(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0A0A0A"))
            setPadding(48, 48, 48, 48)
        }

        val titleText = TextView(this).apply {
            text = "حارس الكرسي الرقمي"
            setTextColor(Color.parseColor("#D4AF37"))
            textSize = 28f
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, 8)
        }

        val subtitleText = TextView(this).apply {
            text = "اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ"
            setTextColor(Color.parseColor("#B8860B"))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 48)
        }

        val statusCard = buildStatusCard()
        val divider = View(this).apply {
            setBackgroundColor(Color.parseColor("#1A1A1A"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 2
            ).also { it.setMargins(0, 32, 0, 32) }
        }

        val logsButton = buildGoldButton("عرض سجل الأمان") {
            showLogsDialog()
        }

        val clearLogsButton = buildOutlineButton("مسح السجل") {
            logManager.clearLogs()
            Toast.makeText(this, "تم مسح سجل الأمان", Toast.LENGTH_SHORT).show()
        }

        val encryptTestButton = buildGoldButton("اختبار التشفير") {
            testEncryption()
        }

        val statusIndicator = TextView(this).apply {
            id = View.generateViewId()
            text = "● الحارس نشط"
            setTextColor(Color.parseColor("#00FF88"))
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 0)
        }

        root.addView(titleText)
        root.addView(subtitleText)
        root.addView(statusCard)
        root.addView(divider)
        root.addView(logsButton)
        root.addView(clearLogsButton)
        root.addView(encryptTestButton)
        root.addView(statusIndicator)

        return root
    }

    private fun buildStatusCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#111111"))
            setPadding(32, 32, 32, 32)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.setMargins(0, 0, 0, 16) }

            val items = listOf(
                "طبقة القيومية (Background Guard)" to "نشطة",
                "طبقة الصمدية (AES-256 Encryption)" to "مفعّلة",
                "طبقة الشهب (Threat Detection)" to "نشطة",
                "طبقة التطهير (Log Purge)" to "تلقائي"
            )
            items.forEach { (label, value) ->
                val row = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, 8, 0, 8)
                }
                val lbl = TextView(context).apply {
                    text = label
                    setTextColor(Color.parseColor("#CCCCCC"))
                    textSize = 12f
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val val_ = TextView(context).apply {
                    text = value
                    setTextColor(Color.parseColor("#D4AF37"))
                    textSize = 12f
                    gravity = Gravity.END
                }
                row.addView(lbl)
                row.addView(val_)
                addView(row)
            }
        }
    }

    private fun buildGoldButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#D4AF37"))
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.setMargins(0, 12, 0, 0) }
            setOnClickListener { onClick() }
        }
    }

    private fun buildOutlineButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setTextColor(Color.parseColor("#D4AF37"))
            setBackgroundColor(Color.TRANSPARENT)
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.setMargins(0, 6, 0, 0) }
            setOnClickListener { onClick() }
        }
    }

    private fun startGuardService() {
        val intent = Intent(this, GuardService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                AlertDialog.Builder(this)
                    .setTitle("تصريح مطلوب")
                    .setMessage("يحتاج الحارس الرقمي إلى صلاحية الظهور فوق التطبيقات الأخرى لحماية جهازك.")
                    .setPositiveButton("منح الإذن") { _, _ ->
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                        startActivity(intent)
                    }
                    .setNegativeButton("لاحقاً", null)
                    .show()
            }
        }
    }

    private fun showLogsDialog() {
        val logs = logManager.readLogs()
        val scrollView = ScrollView(this)
        val textView = TextView(this).apply {
            text = if (logs.isBlank()) "لا توجد أحداث مسجلة." else logs
            setTextColor(Color.parseColor("#CCCCCC"))
            textSize = 12f
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.parseColor("#0A0A0A"))
        }
        scrollView.addView(textView)

        AlertDialog.Builder(this)
            .setTitle("سجل الأمان")
            .setView(scrollView)
            .setPositiveButton("إغلاق", null)
            .show()
    }

    private fun testEncryption() {
        val testData = "بيانات اختبار الحارس الرقمي"
        val encrypted = encryptionManager.encrypt(testData.toByteArray())
        val decrypted = encryptionManager.decrypt(encrypted)
        AlertDialog.Builder(this)
            .setTitle("اختبار التشفير - ناجح")
            .setMessage(
                "النص الأصلي:\n$testData\n\n" +
                "النص المشفر (Base64):\n${android.util.Base64.encodeToString(encrypted, android.util.Base64.DEFAULT).take(64)}...\n\n" +
                "النص بعد فك التشفير:\n${String(decrypted)}"
            )
            .setPositiveButton("تم", null)
            .show()
    }
}
