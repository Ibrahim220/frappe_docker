package com.alkursi.guard

import android.util.Base64
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * طبقة الصمدية (The 11-Layer Samad Vault)
 * AES-256 encryption with key derived from Ayat Al-Kursi.
 * The key is immutable — generated once from the sacred text.
 */
class EncryptionManager {

    // نص آية الكرسي — مصدر المفتاح
    private val ayatAlKursi = """
        اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ
        لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ
        لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ
        مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ
        يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ
        وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ
        وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ
        وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ
    """.trimIndent()

    // عدد حروف آية الكرسي — يُستخدم كـ Salt
    private val saltValue: Int = ayatAlKursi.replace(" ", "").replace("\n", "").length

    private val secretKey: SecretKeySpec by lazy { deriveKey() }

    /**
     * اشتقاق المفتاح من نص الآية الكريمة
     * SHA-256 → 256-bit AES key
     */
    private fun deriveKey(): SecretKeySpec {
        val digest = MessageDigest.getInstance("SHA-256")
        // تكرار الهاش 11 مرة (طبقة الصمدية)
        var hash = ayatAlKursi.toByteArray(Charsets.UTF_8)
        repeat(11) {
            hash = digest.digest(hash + saltValue.toString().toByteArray())
        }
        return SecretKeySpec(hash, "AES")
    }

    /**
     * توليد IV مستخرج من عدد حروف الآية
     */
    private fun deriveIv(): IvParameterSpec {
        val digest = MessageDigest.getInstance("MD5")
        val ivBytes = digest.digest(saltValue.toString().repeat(16).toByteArray())
        return IvParameterSpec(ivBytes)
    }

    /**
     * تشفير البيانات (الحفظ)
     */
    fun encrypt(data: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, deriveIv())
        return cipher.doFinal(data)
    }

    /**
     * فك التشفير (فك القفل بالإذن)
     */
    fun decrypt(encryptedData: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey, deriveIv())
        return cipher.doFinal(encryptedData)
    }

    /**
     * تشفير نص وإرجاعه Base64
     */
    fun encryptString(text: String): String {
        val encrypted = encrypt(text.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }

    /**
     * فك تشفير نص من Base64
     */
    fun decryptString(base64Text: String): String {
        val decoded = Base64.decode(base64Text, Base64.NO_WRAP)
        return String(decrypt(decoded), Charsets.UTF_8)
    }

    /**
     * التحقق من كلمة السر — تُقارن بالمفتاح المشتق من الآية
     */
    fun validatePassword(input: String): Boolean {
        val digest = MessageDigest.getInstance("SHA-256")
        val inputHash = digest.digest(input.toByteArray(Charsets.UTF_8))
        val keyHash = digest.digest(secretKey.encoded)
        return inputHash.contentEquals(keyHash)
    }
}
