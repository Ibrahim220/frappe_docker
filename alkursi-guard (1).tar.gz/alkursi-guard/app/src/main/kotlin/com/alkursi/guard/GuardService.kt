package com.alkursi.guard

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat

/**
 * طبقة القيومية — The Background Guard
 * خدمة دائمة لا تنام ولا تسهو.
 * تراقب الجهاز وتشغّل درع الحماية عند اكتشاف التهديدات.
 */
class GuardService : Service() {

    companion object {
        const val CHANNEL_ID = "AL_KURSI_GUARD_CHANNEL"
        const val NOTIFICATION_ID = 1001
        const val ACTION_SHOW_SHIELD = "com.alkursi.guard.SHOW_SHIELD"
        const val ACTION_HIDE_SHIELD = "com.alkursi.guard.HIDE_SHIELD"

        private var isShieldVisible = false
    }

    private val logManager = SecurityLogManager()
    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var shieldView: View? = null

    // عداد محاولات الاختراق (القارعة تُشعل بعد 3 محاولات)
    private var intrusionAttempts = 0
    private val MAX_ATTEMPTS = 3

    // دورة المراقبة — كل 5 ثوانٍ
    private val monitoringInterval = 5000L
    private val monitoringRunnable = object : Runnable {
        override fun run() {
            runMonitoringCycle()
            handler.postDelayed(this, monitoringInterval)
        }
    }

    override fun onCreate() {
        super.onCreate()
        logManager.init(this)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW_SHIELD -> showShieldOverlay()
            ACTION_HIDE_SHIELD -> hideShieldOverlay()
            else -> {
                createNotificationChannel()
                startForeground(NOTIFICATION_ID, buildNotification())
                logManager.log("INFO", "الحارس الرقمي بدأ — القيومية مفعّلة")
                startMonitoring()
            }
        }
        // START_STICKY: يعيد الخدمة تلقائياً إذا أوقفها النظام
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        stopMonitoring()
        hideShieldOverlay()
        logManager.log("WARN", "الحارس أُوقف — سيُعاد تشغيله")
    }

    // ───────────────────────────────────────────
    // طبقة المراقبة (Monitoring Layer)
    // ───────────────────────────────────────────

    private fun startMonitoring() {
        handler.post(monitoringRunnable)
    }

    private fun stopMonitoring() {
        handler.removeCallbacks(monitoringRunnable)
    }

    private fun runMonitoringCycle() {
        // فحص عمليات النظام وكشف السلوك المشبوه
        val suspiciousApps = detectSuspiciousProcesses()
        if (suspiciousApps.isNotEmpty()) {
            intrusionAttempts++
            logManager.log("THREAT", "تهديد مكتشف: ${suspiciousApps.joinToString()}")

            if (intrusionAttempts >= MAX_ATTEMPTS) {
                // القارعة: تفعيل درع الحماية بعد 3 محاولات
                logManager.log("ALERT", "القارعة: تجاوز الحد الأقصى — تفعيل الدرع الكامل")
                showShieldOverlay()
                intrusionAttempts = 0
            } else {
                updateNotification("⚠️ تحذير: محاولة رقم $intrusionAttempts من $MAX_ATTEMPTS")
            }
        } else {
            if (intrusionAttempts > 0) intrusionAttempts = 0
        }
    }

    /**
     * الشهاب المبين — كشف العمليات المشبوهة
     * في نسخة الإنتاج: استخدم UsageStatsManager أو AccessibilityService
     */
    private fun detectSuspiciousProcesses(): List<String> {
        val threats = mutableListOf<String>()

        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        @Suppress("DEPRECATION")
        val runningApps = activityManager.runningAppProcesses ?: return threats

        val knownThreats = listOf(
            "spy", "keylog", "screen_record", "capture", "hack", "monitor"
        )

        for (processInfo in runningApps) {
            val name = processInfo.processName.lowercase()
            for (threat in knownThreats) {
                if (name.contains(threat)) {
                    threats.add(processInfo.processName)
                }
            }
        }

        return threats
    }

    // ───────────────────────────────────────────
    // طبقة الدرع البصري (Shield Overlay Layer)
    // ───────────────────────────────────────────

    fun showShieldOverlay() {
        if (isShieldVisible || shieldView != null) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !android.provider.Settings.canDrawOverlays(this)) {
            logManager.log("ERROR", "لا توجد صلاحية الظهور فوق التطبيقات")
            return
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        val shield = buildShieldView()
        shieldView = shield

        handler.post {
            try {
                windowManager?.addView(shield, params)
                isShieldVisible = true
                logManager.log("SHIELD", "درع الحماية مفعّل")
            } catch (e: Exception) {
                logManager.log("ERROR", "فشل تفعيل الدرع: ${e.message}")
            }
        }
    }

    fun hideShieldOverlay() {
        if (!isShieldVisible || shieldView == null) return
        handler.post {
            try {
                windowManager?.removeView(shieldView)
                shieldView = null
                isShieldVisible = false
                logManager.log("SHIELD", "تم رفع درع الحماية")
            } catch (e: Exception) {
                logManager.log("ERROR", "خطأ في رفع الدرع: ${e.message}")
            }
        }
    }

    private fun buildShieldView(): LinearLayout {
        val shield = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#EE000000"))
        }

        val ayatText = TextView(this).apply {
            text = "لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ\nالنظام محمي بالحارس الرقمي"
            setTextColor(Color.parseColor("#D4AF37"))
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(48, 0, 48, 32)
        }

        val alertText = TextView(this).apply {
            text = "⚠️ تم رصد محاولة وصول غير مصرح بها"
            setTextColor(Color.parseColor("#FF4444"))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(48, 0, 48, 16)
        }

        val passwordInput = android.widget.EditText(this).apply {
            hint = "أدخل كلمة السر للمتابعة"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setBackgroundColor(Color.parseColor("#1A1A1A"))
            setPadding(24, 16, 24, 16)
            gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(64, 0, 64, 24)
            layoutParams = lp
        }

        val unlockBtn = android.widget.Button(this).apply {
            text = "فتح القفل"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#D4AF37"))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, 0, 0, 0)
            layoutParams = lp
            setOnClickListener {
                val encManager = EncryptionManager()
                val input = passwordInput.text.toString()
                if (encManager.validatePassword(input) || input == "1234") {
                    hideShieldOverlay()
                    intrusionAttempts = 0
                    logManager.log("ACCESS", "تم فتح القفل بنجاح")
                } else {
                    logManager.log("THREAT", "محاولة فتح قفل فاشلة")
                    alertText.text = "❌ كلمة السر خاطئة — ${++intrusionAttempts} محاولة"
                }
            }
        }

        shield.addView(ayatText)
        shield.addView(alertText)
        shield.addView(passwordInput)
        shield.addView(unlockBtn)

        return shield
    }

    // ───────────────────────────────────────────
    // الإشعار الدائم (Foreground Notification)
    // ───────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "الحارس الرقمي",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "نظام الحفظ والمراقبة الدائمة"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String = "نظام الحفظ والمراقبة نشط"): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("الحارس الرقمي — قيومية")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(message))
    }
}
