package com.alkursi.guard

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * طبقة التطهير والسجل (Integrity Log)
 * يسجّل كل الأحداث الأمنية مشفّرةً، ولا تُقرأ إلا بصاحب الشهادة.
 */
class SecurityLogManager {

    private val encryptionManager = EncryptionManager()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    private var logFile: File? = null

    companion object {
        private const val LOG_FILENAME = "kursi_guard_log.dat"
        private const val MAX_LOG_ENTRIES = 500
    }

    fun init(context: Context) {
        logFile = File(context.filesDir, LOG_FILENAME)
    }

    /**
     * تسجيل حدث أمني مشفّر
     * @param level مستوى الحدث: INFO / WARN / THREAT / ALERT / SHIELD / ACCESS / ERROR
     * @param message وصف الحدث
     */
    fun log(level: String, message: String) {
        val file = logFile ?: return
        val timestamp = dateFormat.format(Date())
        val entry = "[$timestamp] [$level] $message"

        try {
            val encryptedEntry = encryptionManager.encryptString(entry)
            val separator = encryptionManager.encryptString("---ENTRY---")

            val existingEntries = if (file.exists()) {
                file.readText().split("\n").filter { it.isNotBlank() }
            } else {
                emptyList()
            }

            // الحد الأقصى للسجلات — مسح القديم (التطهير الدوري)
            val trimmedEntries = if (existingEntries.size >= MAX_LOG_ENTRIES) {
                existingEntries.drop(existingEntries.size - MAX_LOG_ENTRIES + 1)
            } else {
                existingEntries
            }

            val allEntries = (trimmedEntries + encryptedEntry).joinToString("\n")
            file.writeText(allEntries)

        } catch (e: Exception) {
            // صمت برمجي — لا نكشف عن السجل إذا فشل التشفير
        }
    }

    /**
     * قراءة السجل وفك تشفيره (للمسؤول فقط)
     */
    fun readLogs(): String {
        val file = logFile ?: return "لم يتم تهيئة السجل."
        if (!file.exists()) return "لا توجد سجلات."

        return try {
            val lines = file.readText().split("\n").filter { it.isNotBlank() }
            lines.mapNotNull { encryptedLine ->
                try {
                    encryptionManager.decryptString(encryptedLine)
                } catch (_: Exception) {
                    null
                }
            }.joinToString("\n")
        } catch (e: Exception) {
            "خطأ في قراءة السجل: ${e.message}"
        }
    }

    /**
     * مسح السجل — طبقة التطهير (Purge)
     */
    fun clearLogs() {
        logFile?.takeIf { it.exists() }?.delete()
    }

    /**
     * عدد الأحداث المسجّلة
     */
    fun getLogCount(): Int {
        val file = logFile ?: return 0
        if (!file.exists()) return 0
        return file.readText().split("\n").count { it.isNotBlank() }
    }
}
